/**
 * OpenAPI Schemas - Definicionet e schemas për request/response
 */

const schemas = {
    // Standard Error Response
    ErrorResponse: {
        type: 'object',
        required: ['status', 'message'],
        properties: {
            status: {
                type: 'string',
                enum: ['Error'],
                description: 'Status i response-it',
                example: 'Error'
            },
            message: {
                type: 'string',
                description: 'Mesazhi i gabimit',
                example: 'Error message description'
            },
            reason: {
                type: 'string',
                description: 'Arsyeja specifike e gabimit (opsionale)',
                example: 'ErrorReason'
            }
        }
    },
    
    // Standard Success Response
    SuccessResponse: {
        type: 'object',
        required: ['status'],
        properties: {
            status: {
                type: 'string',
                enum: ['Success'],
                description: 'Status i response-it',
                example: 'Success'
            },
            data: {
                type: 'object',
                description: 'Të dhënat e kthyera (varion sipas endpoint-it)',
                additionalProperties: true
            },
            message: {
                type: 'string',
                description: 'Mesazhi i suksesit',
                example: 'Operation completed successfully'
            }
        }
    },
    
    // Login Request Schema
    LoginRequest: {
        type: 'object',
        required: ['username', 'password'],
        properties: {
            username: {
                type: 'string',
                description: 'Username i përdoruesit',
                example: 'user123'
            },
            password: {
                type: 'string',
                format: 'password',
                description: 'Password i përdoruesit',
                example: 'password123'
            },
            AppID: {
                type: 'integer',
                description: 'ID e aplikacionit (opsionale)',
                example: 1
            }
        }
    },
    
    // Login Response Schema
    LoginResponse: {
        type: 'object',
        properties: {
            status: {
                type: 'integer',
                description: 'Status ID (1=Success, 2=Invalid credentials, 3=Other error)',
                example: 1
            },
            user: {
                type: 'object',
                description: 'Informacioni i përdoruesit',
                properties: {
                    ID: {
                        type: 'integer',
                        description: 'ID e përdoruesit',
                        example: 123
                    },
                    Username: {
                        type: 'string',
                        description: 'Username i përdoruesit',
                        example: 'user123'
                    }
                }
            },
            token: {
                type: 'string',
                description: '🔑 JWT token për authentication - Kopjo këtë token dhe përdore në "Authorize" button më lart',
                example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyM30.abc123def456...'
            }
        }
    },
    
    // Change Password Request Schema
    ChangePasswordRequest: {
        type: 'object',
        required: ['NewPassword'],
        properties: {
            NewPassword: {
                type: 'string',
                format: 'password',
                description: 'Password i ri',
                minLength: 1,
                example: 'newPassword123'
            }
        }
    },
    
    // Validation Error Response
    ValidationError: {
        type: 'object',
        properties: {
            status: {
                type: 'string',
                example: 'Error'
            },
            message: {
                type: 'string',
                example: 'Validation failed'
            },
            errors: {
                type: 'array',
                description: 'Lista e gabimeve të validation',
                items: {
                    type: 'object',
                    properties: {
                        field: {
                            type: 'string',
                            description: 'Emri i field-it që ka gabim',
                            example: 'username'
                        },
                        message: {
                            type: 'string',
                            description: 'Mesazhi i gabimit',
                            example: 'Username duhet të jetë tekst'
                        }
                    }
                }
            }
        }
    }
};

/**
 * Merr schema specifike për një endpoint bazuar në handler name
 * @param {string} handlerName - Emri i handler function
 * @param {string} type - 'request' ose 'response'
 * @returns {Object|null} Schema object ose null
 */
function getEndpointSchema(handlerName, type) {
    const schemaMap = {
        // Auth endpoints
        'loginHandler': {
            request: 'LoginRequest',
            response: 'LoginResponse'
        },
        'changePasswordHandler': {
            request: 'ChangePasswordRequest',
            response: 'SuccessResponse'
        },
        'logOutHandeler': {
            response: 'SuccessResponse'
        }
    };
    
    if (schemaMap[handlerName] && schemaMap[handlerName][type]) {
        return schemaMap[handlerName][type];
    }
    
    return null;
}

module.exports = {
    schemas,
    getEndpointSchema
};
