/**
 * Manual Schema Definitions - Për endpoints që kanë struktura komplekse
 * Këto schemas përdoren kur controller analyzer nuk mund të detektojë strukturën e saktë
 */

const manualSchemas = {
  // POST /api-v1/order/ - Save Order
  'saveOrderHandler': {
    body: {
      type: 'object',
      required: ['items', 'CustomerID', 'FilialaID', 'PType'],
      properties: {
        items: {
          type: 'array',
          description: 'Lista e produkteve për porosi',
          minItems: 1,
          items: {
            type: 'object',
            required: ['ItemID', 'Sasia', 'CmimiShites', 'CmimiMeZbritje', 'ZbritjaPerq', 'Totali'],
            properties: {
              ItemID: {
                type: 'integer',
                description: 'ID e produktit',
                example: 123
              },
              Sasia: {
                type: 'integer',
                description: 'Sasia e produktit',
                minimum: 1,
                example: 5
              },
              CmimiShites: {
                type: 'number',
                format: 'float',
                description: 'Çmimi i shitjes për njësi',
                example: 10.50
              },
              CmimiMeZbritje: {
                type: 'number',
                format: 'float',
                description: 'Çmimi me zbritje për njësi',
                example: 9.50
              },
              ZbritjaPerq: {
                type: 'number',
                format: 'float',
                description: 'Zbritja në përqindje',
                example: 10.0
              },
              Totali: {
                type: 'number',
                format: 'float',
                description: 'Totali për këtë produkt (Sasia * CmimiMeZbritje)',
                example: 47.50
              }
            }
          }
        },
        CustomerID: {
          type: 'integer',
          description: 'ID e klientit',
          example: 789
        },
        FilialaID: {
          type: 'integer',
          description: 'ID e filialit',
          example: 1
        },
        PType: {
          type: 'string',
          description: 'Tipi i pagesës',
          example: 'CASH'
        },
        komente: {
          type: 'string',
          description: 'Komente për porosinë',
          example: 'Dorëzim i shpejtë'
        }
      },
      example: {
        items: [
          {
            ItemID: 123,
            Sasia: 5,
            CmimiShites: 10.50,
            CmimiMeZbritje: 9.50,
            ZbritjaPerq: 10.0,
            Totali: 47.50
          },
          {
            ItemID: 456,
            Sasia: 3,
            CmimiShites: 15.00,
            CmimiMeZbritje: 15.00,
            ZbritjaPerq: 0.0,
            Totali: 45.00
          }
        ],
        CustomerID: 789,
        FilialaID: 1,
        PType: 'CASH',
        komente: 'Dorëzim i shpejtë'
      }
    }
  },
  
  // Shto më shumë manual schemas këtu për endpoints të tjerë komplekse
};

/**
 * Merr manual schema për një handler
 * @param {string} handlerName - Handler function name
 * @returns {Object|null} Manual schema ose null
 */
function getManualSchema(handlerName) {
  return manualSchemas[handlerName] || null;
}

module.exports = {
  getManualSchema,
  manualSchemas
};
