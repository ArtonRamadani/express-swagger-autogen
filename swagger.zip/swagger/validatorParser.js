/**
 * Validator Parser - Parseon express-validator rules dhe konverton në OpenAPI schemas
 */

const fs = require('fs');
const path = require('path');
const { analyzeController, getControllerPath } = require('./controllerAnalyzer');
const { getManualSchema } = require('./manualSchemas');

/**
 * Parseon validation rules nga middleware chain
 * @param {Array} middlewares - Array of middleware names
 * @param {string} routePath - Route path për context
 * @param {string} handlerName - Handler function name
 * @returns {Object} Schemas për body, params, query
 */
function parseValidationRules(middlewares, routePath, handlerName) {
  const schemas = {
    body: { type: 'object', properties: {}, required: [] },
    params: { type: 'object', properties: {}, required: [] },
    query: { type: 'object', properties: {}, required: [] }
  };
  
  // STEP 1: Check për manual schemas (priority e lartë për endpoints komplekse)
  const manualSchema = handlerName ? getManualSchema(handlerName) : null;
  if (manualSchema) {
    // Përdor manual schema definitions
    ['body', 'query', 'params'].forEach(location => {
      if (manualSchema[location]) {
        // Nëse manual schema ka 'type' dhe 'properties', përdor tërë schema-n
        if (manualSchema[location].type && manualSchema[location].properties) {
          schemas[location] = manualSchema[location];
        } else {
          // Nëse është një object me fields, merge properties
          Object.keys(manualSchema[location]).forEach(field => {
            schemas[location].properties[field] = manualSchema[location][field];
          });
        }
      }
    });
  } else if (handlerName) {
    const controllerPath = getControllerPath(handlerName, routePath);
    
    if (controllerPath) {
      const fullControllerPath = path.join(process.cwd(), controllerPath);
      const controllerFields = analyzeController(fullControllerPath, handlerName);
      
      ['body', 'query', 'params'].forEach(location => {
        if (controllerFields[location] && controllerFields[location].length > 0) {
          controllerFields[location].forEach(field => {
            schemas[location].properties[field] = {
              type: 'string', // default type
              description: `Field used in controller`
            };
          });
        }
      });
    }
  }
  
  const validationMiddleware = middlewares.find(m => 
    m.includes('Validation') || 
    m.includes('validate') ||
    m.includes('Rules')
  );
  
  if (!validationMiddleware) {
    const pathParams = extractPathParams(routePath);
    if (pathParams.length > 0) {
      pathParams.forEach(param => {
        if (!schemas.params.properties[param]) {
          schemas.params.properties[param] = {
            type: 'string',
            description: `${param} parameter from URL path`
          };
          schemas.params.required.push(param);
        }
      });
    }
    return schemas;
  }
  
  const validatorFile = findValidatorFile(routePath);
  if (!validatorFile) {
    return schemas;
  }
  
  try {
    const validatorModule = require(validatorFile);
    
    const validationFnOrArray = validatorModule[validationMiddleware];
    if (!validationFnOrArray) {
      return schemas;
    }
    
    let rules;
    if (typeof validationFnOrArray === 'function') {
      rules = validationFnOrArray();
    } else if (Array.isArray(validationFnOrArray)) {
      rules = validationFnOrArray;
    } else {
      return schemas;
    }
    
    if (!Array.isArray(rules)) {
      return schemas;
    }
    
    rules.forEach(rule => {
      if (!rule.builder) return;
      
      const field = rule.builder.fields[0];
      const location = rule.builder.locations[0]; // 'body', 'params', 'query'
      
      if (!field || !location || !schemas[location]) return;
      
      const fieldSchema = parseFieldValidators(rule.builder);
      
      schemas[location].properties[field] = fieldSchema;
      
      if (fieldSchema.required) {
        schemas[location].required.push(field);
        delete fieldSchema.required; 
      }
    });
    
    Object.keys(schemas).forEach(location => {
      if (schemas[location].required.length === 0) {
        delete schemas[location].required;
      }
      // if (Object.keys(schemas[location].properties).length === 0) {
      //   schemas[location] = null;
      // }
    });
    
  } catch (error) {
    console.warn(`Warning: Could not parse validators for ${routePath}:`, error.message);
  }
  
  if (!schemas.params || Object.keys(schemas.params.properties).length === 0) {
    const pathParams = extractPathParams(routePath);
    if (pathParams.length > 0) {
      schemas.params = { type: 'object', properties: {}, required: [] };
      pathParams.forEach(param => {
        schemas.params.properties[param] = {
          type: 'string',
          description: `${param} parameter from URL path`
        };
        schemas.params.required.push(param);
      });
    }
  }
  
  if (handlerName) {
    const controllerPath = getControllerPath(handlerName, routePath);
    console.log(`🔍 Controller analysis for ${handlerName}: controllerPath=${controllerPath}`);
    
    if (controllerPath) {
      const fullControllerPath = path.join(process.cwd(), controllerPath);
      console.log(`  📁 Full path: ${fullControllerPath}`);
      console.log(`  📂 File exists: ${require('fs').existsSync(fullControllerPath)}`);
      const controllerFields = analyzeController(fullControllerPath, handlerName);
      console.log(`📊 Controller fields for ${handlerName}:`, JSON.stringify(controllerFields));
      
      ['body', 'query', 'params'].forEach(location => {
        if (controllerFields[location] && controllerFields[location].length > 0) {
          if (!schemas[location]) {
            schemas[location] = { type: 'object', properties: {}, required: [] };
          }
          
          controllerFields[location].forEach(field => {
            if (!schemas[location].properties[field]) {
              schemas[location].properties[field] = {
                type: 'string',
                description: `Field used in controller (not validated)`
              };
              console.log(`  ✅ Added ${location}.${field} from controller`);
            }
          });
        }
      });
    }
  }
  
  return schemas;
}

function parseFieldValidators(builder) {
  const schema = {
    type: 'string', 
    description: ''
  };
  
  let isRequired = false;
  let isOptional = false;
  
  if (!builder.validators || !Array.isArray(builder.validators)) {
    return schema;
  }
  
  builder.validators.forEach(validator => {
    const validatorName = validator.validator;
    const options = validator.options || [];
    
    if (validatorName === 'isString') {
      schema.type = 'string';
    } else if (validatorName === 'isInt') {
      schema.type = 'integer';
      if (options[0]) {
        if (options[0].min !== undefined) schema.minimum = options[0].min;
        if (options[0].max !== undefined) schema.maximum = options[0].max;
        if (options[0].gt !== undefined) schema.minimum = options[0].gt + 1;
        if (options[0].lt !== undefined) schema.maximum = options[0].lt - 1;
      }
    } else if (validatorName === 'isFloat' || validatorName === 'isDecimal') {
      schema.type = 'number';
      schema.format = 'float';
      if (options[0]) {
        if (options[0].min !== undefined) schema.minimum = options[0].min;
        if (options[0].max !== undefined) schema.maximum = options[0].max;
        if (options[0].gt !== undefined) schema.minimum = options[0].gt;
        if (options[0].lt !== undefined) schema.maximum = options[0].lt;
      }
    } else if (validatorName === 'isBoolean') {
      schema.type = 'boolean';
    } else if (validatorName === 'isArray') {
      schema.type = 'array';
      schema.items = { type: 'object' }; // default
      if (options[0]) {
        if (options[0].min !== undefined) schema.minItems = options[0].min;
        if (options[0].max !== undefined) schema.maxItems = options[0].max;
      }
    } else if (validatorName === 'isEmail') {
      schema.type = 'string';
      schema.format = 'email';
    } else if (validatorName === 'isURL') {
      schema.type = 'string';
      schema.format = 'uri';
    } else if (validatorName === 'isDate') {
      schema.type = 'string';
      schema.format = 'date';
    } else if (validatorName === 'isISO8601') {
      schema.type = 'string';
      schema.format = 'date-time';
    } else if (validatorName === 'isUUID') {
      schema.type = 'string';
      schema.format = 'uuid';
    }
    
    if (validatorName === 'isLength') {
      if (options[0]) {
        if (options[0].min !== undefined) schema.minLength = options[0].min;
        if (options[0].max !== undefined) schema.maxLength = options[0].max;
      }
    }
    
    if (validatorName === 'matches') {
      if (options[0]) {
        schema.pattern = options[0].toString().replace(/^\/|\/$/g, '');
      }
    }
    
    if (validatorName === 'isIn') {
      if (options[0] && Array.isArray(options[0])) {
        schema.enum = options[0];
      }
    }
    
    if (validatorName === 'exists' || validatorName === 'notEmpty') {
      isRequired = true;
    }
    if (validatorName === 'optional') {
      isOptional = true;
    }
    
    if (validator.message) {
      if (schema.description) {
        schema.description += '; ' + validator.message;
      } else {
        schema.description = validator.message;
      }
    }
  });
  
  if (isRequired && !isOptional) {
    schema.required = true;
  }
  
  if (!schema.description) {
    delete schema.description;
  }
  
  return schema;
}

function extractPathParams(routePath) {
  const params = [];
  const parts = routePath.split('/');
  
  parts.forEach(part => {
    if (part.startsWith(':')) {
      params.push(part.substring(1)); 
    }
  });
  
  return params;
}

/**
 * Gjej validator file bazuar në route path
 * @param {string} routePath - Route path
 * @returns {string|null} Path to validator file
 */
function findValidatorFile(routePath) {
  // Ekstrakto module name nga path (e.g., /api-v1/auth/login -> auth)
  const pathParts = routePath.split('/').filter(p => p);
  if (pathParts.length < 2) return null;
  
  let moduleName = pathParts[1];
  
  // Handle special cases
  if (moduleName === 'ware-house') moduleName = 'warehouse';
  if (moduleName === 'app') moduleName = 'app';
  
  // Construct validator file path
  const validatorPath = path.join(process.cwd(), 'validators', `${moduleName}.validator.js`);
  
  // Check nëse file ekziston
  if (fs.existsSync(validatorPath)) {
    return validatorPath;
  }
  
  // Try alternative naming
  const altPath = path.join(process.cwd(), 'validators', `${moduleName}.validators.js`);
  if (fs.existsSync(altPath)) {
    return altPath;
  }
  
  // Try singular form
  const singularPath = path.join(process.cwd(), 'validators', `${moduleName.replace(/s$/, '')}.validator.js`);
  if (fs.existsSync(singularPath)) {
    return singularPath;
  }
  
  return null;
}

/**
 * Gjeneron example value bazuar në schema
 * @param {Object} schema - OpenAPI schema
 * @returns {*} Example value
 */
function generateExample(schema) {
  if (!schema || !schema.type) return undefined;
  
  // Nëse ka example të definuar, përdore atë
  if (schema.example !== undefined) return schema.example;
  
  switch (schema.type) {
    case 'string':
      if (schema.format === 'email') return 'user@example.com';
      if (schema.format === 'date') return '2024-01-01';
      if (schema.format === 'date-time') return '2024-01-01T00:00:00Z';
      if (schema.format === 'uuid') return '123e4567-e89b-12d3-a456-426614174000';
      if (schema.enum) return schema.enum[0];
      return 'string';
    case 'integer':
      if (schema.minimum !== undefined) return schema.minimum;
      return 1;
    case 'number':
      if (schema.minimum !== undefined) return schema.minimum;
      return 1.0;
    case 'boolean':
      return true;
    case 'array':
      // Nëse ka items schema, gjenero një example array me një element
      if (schema.items) {
        const itemExample = generateExample(schema.items);
        return itemExample ? [itemExample] : [];
      }
      return [];
    case 'object':
      // Nëse ka properties, gjenero një example object
      if (schema.properties) {
        const obj = {};
        Object.keys(schema.properties).forEach(key => {
          obj[key] = generateExample(schema.properties[key]);
        });
        return obj;
      }
      return {};
    default:
      return undefined;
  }
}

module.exports = {
  parseValidationRules,
  parseFieldValidators,
  generateExample
};
