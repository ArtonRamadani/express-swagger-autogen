/**
 * OpenAPI Generator - Gjeneron OpenAPI 3.0 specification nga Express app
 */

const { inspectRoutes, filterApiRoutes } = require('./routeInspector');
const { parseValidationRules, generateExample } = require('./validatorParser');
const { getRouteMetadata } = require('./metadataExtractor');
/**
 * Gjeneron OpenAPI specification të plotë
 * @param {Express.Application} app - Express application instance
 * @returns {Object} OpenAPI 3.0 specification
 */
function generateOpenApiSpec(app) {
    // Ekstrakto të gjitha routes
    const allRoutes = inspectRoutes(app);
    const apiRoutes = filterApiRoutes(allRoutes);

    // Base OpenAPI spec structure
    const spec = {
        openapi: '3.0.0',
        info: {
            title: 'CBS Mobile API',
            version: '1.0.0',
            description: `Auto-generated API Documentation për CBSMobile Backend System`,
            contact: {
                name: 'API Support'
            }
        },
        servers: [
            {
                url: `http://localhost:${process.env.PORT || 8000}`,
                description: 'Development server'
            },
            {
                url: '{protocol}://{host}:{port}',
                description: 'Custom server',
                variables: {
                    protocol: {
                        enum: ['http', 'https'],
                        default: 'http'
                    },
                    host: {
                        default: 'localhost'
                    },
                    port: {
                        default: process.env.PORT || '8000'
                    }
                }
            }
        ],
        components: {
            securitySchemes: {
                bearerAuth: {
                    type: 'http',
                    scheme: 'bearer',
                    bearerFormat: 'JWT',
                    description: '🔐 JWT token nga /api-v1/auth/login endpoint. Përdor "Authorize" button më poshtë për të vendosur token-in.'
                }
            },
            schemas: {
                // Standard Error Response
                ErrorResponse: {
                    type: 'object',
                    required: ['status', 'message'],
                    properties: {
                        status: {
                            type: 'string',
                            enum: ['Error'],
                            description: 'Status i response-it',
                            example: 'Error'
                        },
                        message: {
                            type: 'string',
                            description: 'Mesazhi i gabimit',
                            example: 'Error message description'
                        },
                        reason: {
                            type: 'string',
                            description: 'Arsyeja specifike e gabimit (opsionale)',
                            example: 'ErrorReason'
                        }
                    }
                },
                
                // Standard Success Response
                SuccessResponse: {
                    type: 'object',
                    required: ['status'],
                    properties: {
                        status: {
                            type: 'string',
                            enum: ['Success'],
                            description: 'Status i response-it',
                            example: 'Success'
                        },
                        data: {
                            type: 'object',
                            description: 'Të dhënat e kthyera (varion sipas endpoint-it)',
                            additionalProperties: true
                        },
                        message: {
                            type: 'string',
                            description: 'Mesazhi i suksesit',
                            example: 'Operation completed successfully'
                        }
                    }
                },
                
                // Login Request Schema
                LoginRequest: {
                    type: 'object',
                    required: ['username', 'password'],
                    properties: {
                        username: {
                            type: 'string',
                            description: 'Username i përdoruesit',
                            example: 'user123'
                        },
                        password: {
                            type: 'string',
                            format: 'password',
                            description: 'Password i përdoruesit',
                            example: 'password123'
                        },
                        AppID: {
                            type: 'integer',
                            description: 'ID e aplikacionit (opsionale)',
                            example: 1
                        }
                    }
                },
                
                // Login Response Schema
                LoginResponse: {
                    type: 'object',
                    properties: {
                        status: {
                            type: 'integer',
                            description: 'Status ID (1=Success, 2=Invalid credentials, 3=Other error)',
                            example: 1
                        },
                        user: {
                            type: 'object',
                            description: 'Informacioni i përdoruesit',
                            properties: {
                                ID: {
                                    type: 'integer',
                                    example: 123
                                },
                                Username: {
                                    type: 'string',
                                    example: 'user123'
                                }
                            }
                        },
                        token: {
                            type: 'string',
                            description: '🔑 JWT token - kopjo këtë dhe përdore në "Authorize" button',
                            example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...'
                        }
                    }
                },
                
                // Change Password Request
                ChangePasswordRequest: {
                    type: 'object',
                    required: ['NewPassword'],
                    properties: {
                        NewPassword: {
                            type: 'string',
                            format: 'password',
                            description: 'Password i ri',
                            example: 'newPassword123'
                        }
                    }
                },
                
                // JWT Error Responses
                JWTMissingError: {
                    type: 'object',
                    properties: {
                        status: {
                            type: 'string',
                            example: 'Error'
                        },
                        reason: {
                            type: 'string',
                            example: 'JWTMissing'
                        },
                        message: {
                            type: 'string',
                            example: 'Access denied. No token provided.'
                        }
                    }
                },
                
                JWTExpiredError: {
                    type: 'object',
                    properties: {
                        status: {
                            type: 'string',
                            example: 'Error'
                        },
                        reason: {
                            type: 'string',
                            example: 'JWTExpired'
                        },
                        message: {
                            type: 'string',
                            example: 'Token has expired. Please log in again.'
                        }
                    }
                },
                
                JWTInvalidError: {
                    type: 'object',
                    properties: {
                        status: {
                            type: 'string',
                            example: 'Error'
                        },
                        reason: {
                            type: 'string',
                            example: 'JWTInvalid'
                        },
                        message: {
                            type: 'string',
                            example: 'Invalid or outdated token.'
                        }
                    }
                },
                
                // Validation Error Response
                ValidationError: {
                    type: 'object',
                    properties: {
                        status: {
                            type: 'string',
                            example: 'Error'
                        },
                        message: {
                            type: 'string',
                            example: 'Validation failed'
                        },
                        errors: {
                            type: 'array',
                            items: {
                                type: 'object',
                                properties: {
                                    field: {
                                        type: 'string',
                                        example: 'username'
                                    },
                                    message: {
                                        type: 'string',
                                        example: 'Username duhet të jetë tekst'
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        tags: [],
        paths: {}
    };

    // Generate tags nga modules
    const modules = new Set();
    apiRoutes.forEach(route => {
        const module = getModuleFromPath(route.path);
        if (module) {
            modules.add(module);
        }
    });

    modules.forEach(module => {
        spec.tags.push({
            name: capitalizeFirstLetter(module),
            description: `${capitalizeFirstLetter(module)} related endpoints`
        });
    });

    // Generate paths
    apiRoutes.forEach(route => {
        generatePathItem(spec, route);
    });

    return spec;
}

/**
 * Gjeneron path item për një route
 * @param {Object} spec - OpenAPI spec object
 * @param {Object} route - Route object nga routeInspector
 */
function generatePathItem(spec, route) {
    const path = route.path;
    const method = route.method.toLowerCase();

    // Krijo path nëse nuk ekziston
    if (!spec.paths[path]) {
        spec.paths[path] = {};
    }

    // Parse validation rules (pass handler name për controller analysis)
    const schemas = parseValidationRules(route.middlewares, route.path, route.handler);

    // Detekto nëse kërkon authentication
    const requiresAuth = route.middlewares.includes('verifyToken');

    // Ekstrakto metadata nga comments (nëse ka)
    const metadata = getRouteMetadata(route.path);

    // Përdor metadata summary nëse available, otherwise auto-generate
    const summary = metadata.summary || generateSummary(route);
    const description = metadata.description || '';

    // Gjenero tag nga module
    const tag = getModuleFromPath(path);

    // Krijo endpoint definition
    const endpoint = {
        summary: summary,
        description: description,
        tags: tag ? [capitalizeFirstLetter(tag)] : ['Other'],
        security: requiresAuth ? [{ bearerAuth: [] }] : []
    };

    // Shto parameters (path dhe query params)
    const parameters = generateParameters(schemas.params, schemas.query, path);
    if (parameters.length > 0) {
        endpoint.parameters = parameters;
    }

    // Shto requestBody (për POST, PUT, PATCH)
    if (['post', 'put', 'patch'].includes(method)) {
        // Special handling për login endpoint
        if (route.handler === 'loginHandler') {
            endpoint.requestBody = {
                required: true,
                content: {
                    'application/json': {
                        schema: {
                            $ref: '#/components/schemas/LoginRequest'
                        },
                        example: {
                            username: 'user123',
                            password: 'password123',
                            AppID: 1
                        }
                    }
                }
            };
        } else if (route.handler === 'changePasswordHandler') {
            endpoint.requestBody = {
                required: true,
                content: {
                    'application/json': {
                        schema: {
                            $ref: '#/components/schemas/ChangePasswordRequest'
                        }
                    }
                }
            };
        } else if (schemas.body && Object.keys(schemas.body.properties).length > 0) {
            endpoint.requestBody = generateRequestBody(schemas.body);
        }
    }

    // Shto responses
    endpoint.responses = generateResponses(route, schemas);

    spec.paths[path][method] = endpoint;

    return endpoint;
}

/**
 * Gjeneron summary automatikisht nga route
 * @param {Object} route - Route object
 * @returns {string} Auto-generated summary
 */
function generateSummary(route) {
    const method = route.method.toUpperCase();
    const pathParts = route.path.split('/').filter(p => p && !p.startsWith(':'));

    // Action mapping
    const actionMap = {
        'GET': 'Merr',
        'POST': 'Krijo/Ekzekuto',
        'PUT': 'Përditëso',
        'PATCH': 'Modifiko',
        'DELETE': 'Fshi'
    };

    const action = actionMap[method] || method;

    // Resource name (last non-param part)
    let resource = pathParts[pathParts.length - 1] || 'resource';
    resource = capitalizeFirstLetter(resource);

    return `${action} ${resource}`;
}

/**
 * Ekstrakton module name nga path
 * @param {string} path - Route path
 * @returns {string|null} Module name
 */
function getModuleFromPath(path) {
    const parts = path.split('/').filter(p => p);
    if (parts.length < 2) return null;

    // parts[0] është 'api-v1', parts[1] është module
    let module = parts[1];

    // Clean up module name
    if (module === 'ware-house') module = 'warehouse';

    return module;
}

/**
 * Capitalize first letter
 * @param {string} str - String to capitalize
 * @returns {string} Capitalized string
 */
function capitalizeFirstLetter(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
}

/**
 * Gjeneron parameters array për path dhe query params
 * @param {Object} paramsSchema - Schema për path parameters
 * @param {Object} querySchema - Schema për query parameters
 * @param {string} path - Route path
 * @returns {Array} Parameters array
 */
function generateParameters(paramsSchema, querySchema, path) {
    const parameters = [];

    // Path parameters
    if (paramsSchema && paramsSchema.properties) {
        Object.keys(paramsSchema.properties).forEach(paramName => {
            const schema = paramsSchema.properties[paramName];
            const isRequired = paramsSchema.required && paramsSchema.required.includes(paramName);

            parameters.push({
                in: 'path',
                name: paramName,
                required: isRequired !== false, // Path params janë gjithmonë required
                schema: {
                    type: schema.type || 'string',
                    ...(schema.format && { format: schema.format }),
                    ...(schema.minimum !== undefined && { minimum: schema.minimum }),
                    ...(schema.maximum !== undefined && { maximum: schema.maximum }),
                    ...(schema.pattern && { pattern: schema.pattern }),
                    ...(schema.enum && { enum: schema.enum })
                },
                description: schema.description || `${paramName} parameter`
            });
        });
    }

    // Query parameters
    if (querySchema && querySchema.properties) {
        Object.keys(querySchema.properties).forEach(paramName => {
            const schema = querySchema.properties[paramName];
            const isRequired = querySchema.required && querySchema.required.includes(paramName);

            parameters.push({
                in: 'query',
                name: paramName,
                required: isRequired || false,
                schema: {
                    type: schema.type || 'string',
                    ...(schema.format && { format: schema.format }),
                    ...(schema.minimum !== undefined && { minimum: schema.minimum }),
                    ...(schema.maximum !== undefined && { maximum: schema.maximum }),
                    ...(schema.pattern && { pattern: schema.pattern }),
                    ...(schema.enum && { enum: schema.enum })
                },
                description: schema.description || `${paramName} query parameter`
            });
        });
    }

    return parameters;
}

/**
 * Gjeneron requestBody object
 * @param {Object} bodySchema - Schema për request body
 * @returns {Object} RequestBody object
 */
function generateRequestBody(bodySchema) {
    if (!bodySchema || !bodySchema.properties || Object.keys(bodySchema.properties).length === 0) {
        return undefined;
    }

    // Generate example object
    const example = {};
    Object.keys(bodySchema.properties).forEach(key => {
        example[key] = generateExample(bodySchema.properties[key]);
    });

    return {
        required: true,
        content: {
            'application/json': {
                schema: bodySchema,
                example: example
            }
        }
    };
}

/**
 * Gjeneron responses object për endpoint
 * @param {Object} route - Route object
 * @param {Object} schemas - Parsed schemas
 * @returns {Object} Responses object
 */
function generateResponses(route, schemas) {
    const responses = {};
    const method = route.method.toUpperCase();
    const requiresAuth = route.middlewares.includes('verifyToken');
    const handler = route.handler;

    // Success response (200 or 201) - use specific schemas for known endpoints
    const successCode = method === 'POST' ? '201' : '200';
    
    // Special handling for login endpoint
    if (handler === 'loginHandler') {
        responses['200'] = {
            description: '✅ Login i suksesshëm - Kopjo token-in dhe përdore në "Authorize" button',
            content: {
                'application/json': {
                    schema: {
                        $ref: '#/components/schemas/LoginResponse'
                    }
                }
            }
        };
    } else {
        // Generic success response
        responses[successCode] = {
            description: method === 'POST' ? '✅ Resource u krijua me sukses' : '✅ Operacioni u krye me sukses',
            content: {
                'application/json': {
                    schema: {
                        $ref: '#/components/schemas/SuccessResponse'
                    },
                    example: {
                        status: 'Success',
                        message: 'Operation completed successfully',
                        data: {}
                    }
                }
            }
        };
    }

    // Validation error (400)
    if (schemas.body || schemas.params || schemas.query) {
        responses['400'] = {
            description: '❌ Validation Error - Të dhënat e dërguara janë invalide',
            content: {
                'application/json': {
                    schema: {
                        $ref: '#/components/schemas/ValidationError'
                    }
                }
            }
        };
    }

    // Authentication errors (401, 403)
    if (requiresAuth) {
        responses['401'] = {
            description: '🔒 Unauthorized - Token mungon ose është invalid',
            content: {
                'application/json': {
                    schema: {
                        oneOf: [
                            { $ref: '#/components/schemas/JWTMissingError' },
                            { $ref: '#/components/schemas/JWTInvalidError' }
                        ]
                    },
                    examples: {
                        missing: {
                            summary: 'Token mungon',
                            value: {
                                status: 'Error',
                                reason: 'JWTMissing',
                                message: 'Access denied. No token provided.'
                            }
                        },
                        invalid: {
                            summary: 'Token invalid',
                            value: {
                                status: 'Error',
                                reason: 'JWTInvalid',
                                message: 'Invalid or outdated token.'
                            }
                        }
                    }
                }
            }
        };

        responses['403'] = {
            description: '🔒 Forbidden - Token ka skaduar',
            content: {
                'application/json': {
                    schema: {
                        $ref: '#/components/schemas/JWTExpiredError'
                    }
                }
            }
        };
    }

    // Not acceptable (406) - business logic error
    responses['406'] = {
        description: '⚠️ Not Acceptable - Gabim në logjikën e biznesit (p.sh. kredenciale të gabuara)',
        content: {
            'application/json': {
                schema: {
                    $ref: '#/components/schemas/ErrorResponse'
                },
                example: {
                    status: 'Error',
                    message: 'Operation could not be completed'
                }
            }
        }
    };

    // Server error (500)
    responses['500'] = {
        description: '💥 Internal Server Error - Gabim i brendshëm i serverit',
        content: {
            'application/json': {
                schema: {
                    $ref: '#/components/schemas/ErrorResponse'
                },
                example: {
                    status: 'Error',
                    message: 'Internal server error occurred'
                }
            }
        }
    };

    return responses;
}

module.exports = {
    generateOpenApiSpec
};
